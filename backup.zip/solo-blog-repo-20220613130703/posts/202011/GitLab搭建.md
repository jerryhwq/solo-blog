title: GitLab搭建
date: '2020-11-08 11:51:46'
updated: '2021-10-02 15:08:43'
tags: [GitLab]
permalink: /articles/2020/11/08/1604807506063.html
---
首先安装docker和docker-compose，然后新建doker-compose.yml并配置如下：

```yaml
gitlab:
  image: 'gitlab/gitlab-ce:latest'
  restart: always
  hostname: 'git.example.com'
  ports:
    - '80:80'
    - '443:443'
    - '9922:22'
  volumes:
    - '/srv/gitlab/config:/etc/gitlab'
    - '/srv/gitlab/logs:/var/log/gitlab'
    - '/srv/gitlab/data:/var/opt/gitlab'
```

然后根据需要修改 `/srv/gitlab/config/gitlab.rb`文件，然后重启容器或者或者进入到容器内执行 `gitlab-ctl reconfigure`命令使新配置生效

smtp配置成功以后可以进入容器，执行 `gitlab-rails console`，然后再执行 `Notify.test_email('test@example.com', 'Subject', 'Text').deliver_now`发送一封邮件来检查smtp配置

由于git的ssh和系统ssh都使用22号端口，所以需要映射出来的端口需要不一样，或者服务器有多个ip，ssh和gitlab分别监听不同ip的22号端口。

如果只有一个ip，又觉得ssh clone的地址是ssh://git@git.example.com:9922/xxx/xxx.git这样的格式不好看，需要进行一些配置：

* 进入到容器内查看 `/etc/group`和 `/etc/passwd`中git用户配置的gid和uid，这里假设都是998
* 在宿主机上使用 `groupadd -g 998 git`和 `useradd -m -u 998 -g git -s /bin/sh -d /home/git git`创建和容器内相同gid和uid
* 同时再将 `/srv/gitlab/data/.ssh/authorized_keys`软链接到 `/home/git/.ssh/authorized_keys`，这个文件是由gitlab创建，用于git ssh认证用的
* 如果在网页上已经添加过ssh key会发现authorized_keys最前面有一个command，使用的命令的文件实际上是docker容器内的文件，在ssh连接的时候实际上会执行这个command，所以我们在宿主机中建立一个同名的文件 `/opt/gitlab/embedded/service/gitlab-shell/bin/gitlab-shell`，内容如下：
  
  ```sh
  #!/bin/sh
  ssh -i /home/git/.ssh/id_rsa -p 9922 -o StrictHostKeyChecking=no git@127.0.0.1 "SSH_ORIGINAL_COMMAND=\"$SSH_ORIGINAL_COMMAND\" $0 $@"
  ```
* 上面文件的作用就是将ssh连接转发到9922端口，这样就就交给容器了，这里实际上还是一个ssh连接做的转发，宿主机连接到容器还需要一次然认证，所以需要使用 `su git`命令切换为git用户，使用 `ssh-keygen -t rsa -b 4096`生成ssh key
* 把 `/home/git/.ssh/id_rsa.pub`修改为 `/home/git/.ssh/authorized_keys_proxy`，再将这个文件映射为容器内/gitlab-data/ssh/authorized_keys文件
* 在[这次提交](https://gitlab.com/gitlab-org/omnibus-gitlab/commit/923fd761ed854ca368c413a581b1153cd677dbe5)中，添加了除了 `/.ssh/authorized_keys`以外的 `/gitlab-data/authorized_keys`文件用于ssh认证，这样就可以宿主机的git账户就可以连接到容器了
* 这样就可以`git clone git@example.com:xxx/xxx.git`的方式进行操作了，同时之前的9922端口可以限制为只监听127.0.0.1

最终配置如下：

```yaml
gitlab:
  image: 'gitlab/gitlab-ce:latest'
  restart: always
  hostname: 'git.example.com'
  ports:
    - '80:80'
    - '443:443'
    - '127.0.0.1:9922:22'
  volumes:
    - '/srv/gitlab/config:/etc/gitlab'
    - '/srv/gitlab/logs:/var/log/gitlab'
    - '/srv/gitlab/data:/var/opt/gitlab'
    - '/home/git/.ssh/authorized_keys_proxy:/gitlab-data/ssh/authorized_keys'
```


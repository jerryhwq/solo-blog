title: 使用AWS服务搭建Gitea服务器
date: '2026-01-11 13:23:05'
updated: '2026-01-11 13:33:39'
tags: [AWS, Gitea]
permalink: /articles/2026/01/11/1768108985695.html
---
1. VPC
   创建一个带有公有子网和私有子网的VPC, 名为vpc-git

   并修改VPC的子网设置，公有子网选择启用自动分配IP地址和资源DNS解析记录
2. ACM
   创建一个SSL证书, 注意Region需要是us-east-1, CloudFront只能使用这个区域的证书
3. IAM
   在IAM中创建一个Policy, 名为iam-policy-s3-git, 用于EC2在不配置Access Key的情况下访问S3, 权限配置如下:

   ```json
   {
       "Version": "2012-10-17",
       "Statement": [
           {
               "Sid": "VisualEditor0",
               "Effect": "Allow",
               "Action": [
                   "s3:PutObject",
                   "s3:GetObject",
                   "s3:ListBucket",
                   "s3:DeleteObject"
               ],
               "Resource": [
                   "arn:aws:s3:::s3-git",
                   "arn:aws:s3:::s3-git/*"
               ]
           },
           {
               "Sid": "VisualEditor1",
               "Effect": "Allow",
               "Action": "s3:ListAllMyBuckets",
               "Resource": "*"
           }
       ]
   }
   ```
   创建一个IAM Role, 名为iam-role-ec2-git

   * Trusted entity type选择AWS service
   * Service or use case和Use case都选择EC2
   * Permissions policies选择iam-policy-s3-git
4. S3
   创建一个S3 Bucket, 名为s3-git
5. Security Group
   创建安全组sg-ssh, inbound放通0.0.0.0/0的TCP 22端口,方便后续连接服务器进行配置

   下面所有的安全组outbound都放通0.0.0.0/0的All Traffic方便使用, 也可精确放通某一个

   创建安全组sg-alb-git-http, 后续还有其他配置需要添加

   创建安全组sg-nlb-git-ssh, inbound放通0.0.0.0/TCP 22端口, 方便ssh连接Git服务器

   创建安全组sg-ec2-git, inbound放通sg-alb-git-http的TCP 3000端口, 用于网页访问, 放通TCP 2222端口用于SSH连接

   创建安全组sg-valkey-git, inbound放通sg-ec2-git的TCP 6379端口, 用于EC2访问Valkey

   创建安全组sg-rds-git, inbound放通sg-ec2-git的TCP 5432端口, 用于EC2访问PostgreSQL
6. Postgre
   创建一个数据库, 名为rds-git, 安全组选择sg-rds-git, 注意设置初始数据库名和用户名密码, 并记住Endpoint地址
7. Valkey
   创建一个Valkey, 名为valkey-git, 安全组选择sg-valkey-git, 注意设置是否强制SSL及密码, 并记住Endpoint地址

   可以只选私有子网
8. EC2
   创建一个EC2服务器, 使用公有子网, 名为ec2-git, 安全组选择sg-ec2-git和sg-ssh, 安装并配置Gitea

   为EC2服务器授予iam-role-ec2-git
9. ALB
   创建一个Target Group, 名为tg-git-http, Protocol为HTTP, Port为80, target选择ec2-git的HTTP 3000端口

   创建一个ALB, 名为alb-git-http

   * Scheme选择Internal
   * Availability Zones and subnets中选择私有子网
   * 安全组选择sg-alb-git-http
   * Listener选择Protocol HTTP, Port 80, Routing action选择Foward to target groups, Target group选择tg-git-http
10. CloudFront
    创建一个VPC origin, 名为vpc-origin-git, Protocol选择HTTP only, Origin ARN为alb-git-http, HTTP port为80

    VPC origin创建后会自动生成一个名为CloudFront-VPCOrigins-Service-SG的安全组, 需要在sg-alb-git中inbound放通CloudFront-VPCOrigins-Service-SG的TCP 80端口

    创建一个CloudFront节点, 名为cdn-git

    * 填写一个域名, 要和上面在ACM中的证书兼容
    * Origin type选择VPC origin并选择Origin为vpc-origin-git
    * Cache Settings选择Customize cache Settings
    * Allowed HTTP methods选择GET, HEAD, OPTIONS, PUT, POST, PATCH, DELETE
    * Cache policy选择Caching Disabled
    * Origin request policy选择All Viewer

    创建完成后在Behaviours中添加两个新的Behaviour, 确保新创建的Behaviour在Default之上

    * Origin and origin groups选择唯一的一个origin
    * Path pattern分别填写/assets/\* 和/avatars/\*
    * Allowed HTTP methods选择GET, HEAD
    * Cache policy选择UseOriginCacheControlHeaders-QueryStrings
11. NLB
    创建一个Target Group, 名为tg-git-ssh, Protocol为TCP, Port为22, target选择ec2-git的TCP 2222端口

    创建一个NLB, 名为nlb-git-ssh

    * Scheme选择Internet-facing
    * Availability Zones and subnets中选择公有子网
    * 安全组选择sg-nlb-git-ssh
    * Listener选择Protocol TCP, Port 22, Target group选择tg-git-ssh
12. GA
    创建一个GA, 名为ga-git-ssh

    * Ports为22, Protocol为TCP
    * Region选择NLB所在的Region
    * 添加一个Endpoint, Endpoint type选择Network Load Balancer, Endpoint选择nlb-git-ssh
13. Gitea参考配置
    docker-compose.yaml

    ```yaml
    services:
      gitea:
        image: gitea/gitea:1.25
        restart: always
        environment:
          - USER_UID=1001
          - USER_GID=1001
        volumes:
          - /data/gitea:/data
          - /etc/timezone:/etc/timezone:ro
          - /etc/localtime:/etc/localtime:ro
        ports:
          - 3000:3000
          - 2222:22
    ```
    app.ini

    ```ini
    APP_NAME = Gitea: Git with a cup of tea
    RUN_MODE = prod
    RUN_USER = git
    WORK_PATH = /data/gitea

    [repository]
    ROOT = /data/git/repositories

    [repository.local]
    LOCAL_COPY_PATH = /data/gitea/tmp/local-repo

    [repository.upload]
    TEMP_PATH = /data/gitea/uploads

    [server]
    APP_DATA_PATH = /data/gitea
    DOMAIN = git.huwenqiang.cn
    SSH_DOMAIN = ssh.git.huwenqiang.cn
    HTTP_PORT = 3000
    ROOT_URL = https://git.huwenqiang.cn/
    DISABLE_SSH = false
    SSH_PORT = 22
    SSH_LISTEN_PORT = 22
    LFS_START_SERVER = true
    LFS_JWT_SECRET = 
    OFFLINE_MODE = true

    [database]
    PATH = /data/gitea/gitea.db
    DB_TYPE = postgres
    HOST = git-huwenqiang-cn.xxxxxxxxxxxx.ap-east-1.rds.amazonaws.com
    NAME = gitea
    USER = gitea
    PASSWD = 
    LOG_SQL = false
    SCHEMA =
    SSL_MODE = require

    [indexer]
    ISSUE_INDEXER_PATH = /data/gitea/indexers/issues.bleve
    REPO_INDEXER_ENABLED = true
    REPO_INDEXER_REPO_TYPES = sources,forks,mirrors,templates
    REPO_INDEXER_TYPE = bleve

    [session]
    PROVIDER = redis
    PROVIDER_CONFIG = rediss://clustercfg.git-huwenqiang-cn.xxxxxx.ape1.cache.amazonaws.com:6379/0?pool_size=100&idle_timeout=180s

    [picture]
    AVATAR_UPLOAD_PATH = /data/gitea/avatars
    REPOSITORY_AVATAR_UPLOAD_PATH = /data/gitea/repo-avatars
    DISABLE_GRAVATAR = false
    ENABLE_FEDERATED_AVATAR = true
    REPOSITORY_AVATAR_FALLBACK = random

    [attachment]
    PATH = /data/gitea/attachments
    STORAGE_TYPE = minio
    SERVE_DIRECT = true

    [log]
    MODE = file
    LEVEL = info
    ROOT_PATH = /data/gitea/log

    [security]
    INSTALL_LOCK = true
    SECRET_KEY =
    REVERSE_PROXY_LIMIT = 1
    REVERSE_PROXY_TRUSTED_PROXIES = *
    INTERNAL_TOKEN = 
    PASSWORD_HASH_ALGO = pbkdf2

    [service]
    DISABLE_REGISTRATION = true
    REQUIRE_SIGNIN_VIEW = true
    REGISTER_EMAIL_CONFIRM = false
    ENABLE_NOTIFY_MAIL = false
    ALLOW_ONLY_EXTERNAL_REGISTRATION = false
    ENABLE_CAPTCHA = false
    DEFAULT_KEEP_EMAIL_PRIVATE = false
    DEFAULT_ALLOW_CREATE_ORGANIZATION = true
    DEFAULT_ENABLE_TIMETRACKING = true
    NO_REPLY_ADDRESS = noreply.git.huwenqiang.cn

    [lfs]
    PATH = /data/git/lfs
    STORAGE_TYPE = minio
    SERVE_DIRECT = true

    [mailer]
    ENABLED = false

    [openid]
    ENABLE_OPENID_SIGNIN = false
    ENABLE_OPENID_SIGNUP = false

    [cron.update_checker]
    ENABLED = true

    [repository.pull-request]
    DEFAULT_MERGE_STYLE = merge

    [repository.signing]
    DEFAULT_TRUST_MODEL = committer

    [oauth2]
    JWT_SECRET = 

    [federation]
    ENABLED = true

    [packages]
    ENABLED = true
    STORAGE_TYPE = minio
    SERVE_DIRECT = true

    [repo-archive]
    STORAGE_TYPE = minio

    [storage]
    STORAGE_TYPE = minio
    MINIO_ENDPOINT = s3.ap-east-1.amazonaws.com
    MINIO_BUCKET = storage-git-huwenqiang-cn
    MINIO_LOCATION = ap-east-1
    MINIO_USE_SSL = true
    MINIO_BUCKET_LOOKUP_TYPE = dns

    [storage.minio]
    STORAGE_TYPE = minio
    MINIO_ENDPOINT = s3.ap-east-1.amazonaws.com
    MINIO_BUCKET = storage-git-huwenqiang-cn
    MINIO_LOCATION = ap-east-1
    MINIO_USE_SSL = true
    MINIO_BUCKET_LOOKUP_TYPE = dns

    [actions]
    ENABLED = true

    [storage.actions_log]
    STORAGE_TYPE = minio
    ```

title: 续期域名在阿里云上的Let's Encrypt泛域名证书
date: '2019-03-24 14:38:18'
updated: '2019-03-24 14:50:13'
tags: [letsencrypt]
permalink: /articles/2019/03/24/1553409497931.html
---
首先使用pip安装aliyun-python-sdk-alidns，然后新建如下脚本，并将access_key_id和access_key_secret换掉

```python3
import os
from aliyunsdkcore.client import AcsClient
from aliyunsdkalidns.request.v20150109 import AddDomainRecordRequest

access_key_id =  'access_key_id'
access_key_secret =  'access_key_secret'

domain = os.environ["CERTBOT_DOMAIN"]
value = os.environ["CERTBOT_VALIDATION"]

print("--------------->domain="  + domain)
print("--------------->value="  + value)

client = AcsClient(access_key_id, access_key_secret)
request = AddDomainRecordRequest.AddDomainRecordRequest()
request.set_DomainName(domain)
request.set_RR('_acme-challenge')
request.set_Type('TXT')
request.set_Value(value)
response = client.do_action_with_exception(request)

print(response)
```

之后执行下面的命令就可以自动添加解析记录并续期
```bash
./certbot-auto renew --manual --preferred-challenges dns  --manual-auth-hook ./dns.py
```

title: Zinit配置
date: '2021-04-21 10:03:14'
updated: '2021-10-05 13:36:02'
tags: [Zinit, zsh]
permalink: /articles/2021/10/02/1618970594540.html
---
# 安装

1. 首先执行官方安装脚本

```zsh
sh -c "$(curl -fsSL https://raw.githubusercontent.com/zdharma/zinit/master/doc/install.sh)"
```

# 添加相关插件

2. 在``~/.zshrc``中添加配置并source安装插件

```zsh
# z.lua
zinit ice lucid wait='1'
zinit light skywind3000/z.lua
# p10k界面
zinit ice depth=1
zinit light romkatv/powerlevel10k
# 高亮
zinit ice lucid wait='0' atinit='zpcompinit'
zinit light zdharma/fast-syntax-highlighting
# 提示
zinit ice lucid wait='0' atload='_zsh_autosuggest_start'
zinit light zsh-users/zsh-autosuggestions
# 自动补全
zinit ice lucid wait='0'
zinit light zsh-users/zsh-completions
```

* 需要注意p10k可能需要安装相关字体才能使用除了pure以外的主题配置

# ZSH启动慢

如果觉得ZSH启动过慢，可以执行如下命令zinit提供的插件进行检测

```zsh
zinit module build
```

并根据提示将以下内容加到 ``~/.zshrc``最前面

```zsh
module_path+=( "$HOME/.zinit/bin/zmodules/Src" )
zmodload zdharma/zplugin
```

如果提示找不到文件，可能需要修改编译参数，将 `~/.zinit/bin/zinit-autoload.zsh`文件中下面这行添加 ``-Wno-implicit-function-declaration``参数到 ``CFLAGS``中重新执行编译命令即可

```zsh
CPPFLAGS=-I/usr/local/include CFLAGS="-g -Wall -O3" LDFLAGS=-L/usr/local/lib ./configure --disable-gdbm --without-tcsetpgrp
```

关闭并重新打开一个新的shell，执行 `zpmod source-study -l`即可查看到每个脚本的启动时间，将耗时较长的脚本延迟加载或删除以加快启动速度

title: 使用nginx的acme模块申请SSL证书
date: '2026-01-11 21:49:17'
updated: '2026-01-11 21:58:13'
tags: [nginx, acme, ssl, https]
permalink: /articles/2026/01/11/1768139357068.html
---
nginx从2025年(1.28, 最低似乎兼容1.22)开始提供ngx_http_acme_module, 现在可以不依赖acme.sh或certbot等工具的情况下使用HTTPS

下面以Debian为例, 使用nginx自带的acme模块进行SSL证书的申请与使用

1. 安装nginx及ngx\_http\_acme\_module

   > 参考链接: [nginx: Linux packages](https://nginx.org/en/linux_packages.html)
   >

   ```bash
   # 安装依赖库
   sudo apt install curl gnupg2 ca-certificates lsb-release debian-archive-keyring
   # 导入Key
   curl https://nginx.org/keys/nginx_signing.key | gpg --dearmor \
       | sudo tee /usr/share/keyrings/nginx-archive-keyring.gpg >/dev/null
   # 设置源
   echo "deb [signed-by=/usr/share/keyrings/nginx-archive-keyring.gpg] \
   https://nginx.org/packages/debian `lsb_release -cs` nginx" \
       | sudo tee /etc/apt/sources.list.d/nginx.list
   # 设置优先级
   echo -e "Package: *\nPin: origin nginx.org\nPin: release o=nginx\nPin-Priority: 900\n" \
       | sudo tee /etc/apt/preferences.d/99nginx
   sudo apt update
   # 安装nginx
   sudo apt install nginx
   # 安装ngx_http_acme_module
   apt install nginx-module-acme
   ```
2. 配置

   > 参考链接:
   >
   > [Module ngx\_http\_acme\_module](https://nginx.org/en/docs/http/ngx_http_acme_module.html)
   >
   > [Mozilla SSL Configuration Generator](https://ssl-config.mozilla.org/#server=nginx&version=1.28.1&config=intermediate&openssl=3.5.4&guideline=5.7)
   >

   nginx.conf配置参考

   ```nginx
   # 引入ngx_http_acme_module模块
   load_module modules/ngx_http_acme_module.so;

   user  nginx;
   worker_processes  auto;

   error_log  /var/log/nginx/error.log notice;
   pid        /run/nginx.pid;

   events {
       worker_connections  1024;
   }

   http {
       include       /etc/nginx/mime.types;
       default_type  application/octet-stream;

       log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                         '$status $body_bytes_sent "$http_referer" '
                         '"$http_user_agent" "$http_x_forwarded_for"';

       access_log  /var/log/nginx/access.log  main;

       sendfile        on;
       #tcp_nopush     on;

       keepalive_timeout  65;

       #gzip  on;
       # 设置DNS服务器, 这里因为服务器是AWS EC2使用的是AWS EC2专用的DNS服务器, 根据需要可以改为8.8.8.8, 223.5.5.5, 1.1.1.1等
       resolver 169.254.169.253 valid=300s;

       # intermediate configuration
       ssl_protocols TLSv1.2 TLSv1.3;
       ssl_ecdh_curve X25519:prime256v1:secp384r1;
       ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384:DHE-RSA-CHACHA20-POLY1305;
       ssl_prefer_server_ciphers off;

       # see also ssl_session_ticket_key alternative to stateful session cache
       ssl_session_timeout 1d;
       ssl_session_cache shared:MozSSL:10m;  # about 40000 sessions

       # sudo curl -o /etc/nginx/dhparam.pem https://ssl-config.mozilla.org/ffdhe2048.txt
       ssl_dhparam /etc/nginx/dhparam.pem;

       # OCSP stapling
       ssl_stapling on;
       ssl_stapling_verify on;

   	# 配置, Let's Encrypt相对简单
       acme_issuer letsencrypt {
           # 指定服务器
           uri https://acme-v02.api.letsencrypt.org/directory;
           # 接受服务条款
           accept_terms_of_service;
           # 通知邮件
           contact mailto:xxx@xxx.xxx;
           # 证书保存路径, 默认位置: /var/cache/nginx/acme_<issuer>
           # state_path acme_<issuer>;
       }

       include /etc/nginx/conf.d/*.conf;
   }
   ```
   HTTP配置参考:

   ```nginx
   map $http_upgrade $connection_upgrade {
       default upgrade;
       '' close;
   }

   server {
       listen       443 ssl;
       listen  [::]:443 ssl;
       http2 on;

       server_name  www.huwenqiang.cn;

       # 这里使用ECC证书, 也可以使用RSA, 改为rsa:2048即可
       acme_certificate letsencrypt key=ecdsa:256;
       # 这里证书路径改为ngx_http_acme_module提供的两个变量
       ssl_certificate $acme_certificate;
       ssl_certificate_key $acme_certificate_key;
       ssl_session_tickets off;
       ssl_certificate_cache max=2;

       # HSTS
       add_header Strict-Transport-Security "max-age=63072000" always;

       gzip on;
       gzip_vary on;
       gzip_proxied any;
       gzip_comp_level 6;
       gzip_min_length 1k;
       gzip_static on;
       gzip_types text/plain text/css text/javascript application/javascript application/x-javascript application/json application/xml application/rss+xml image/svg+xml;

       location / {
           proxy_pass http://localhost:8080;
           proxy_set_header  Host $http_host;
           proxy_set_header  X-Real-IP $remote_addr;
           proxy_http_version 1.1;
           proxy_set_header Connection "";
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection $connection_upgrade;
       }

       #error_page  404              /404.html;

       # redirect server error pages to the static page /50x.html
       error_page   500 502 503 504  /50x.html;
       location = /50x.html {
           root   /usr/share/nginx/html;
       }
   }

   server {
       listen 80;
       listen [::]:80;
       server_name www.huwenqiang.cn;
       return 301 https://www.huwenqiang.cn$request_uri;
   }
   ```

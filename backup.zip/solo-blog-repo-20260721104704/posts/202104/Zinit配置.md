title: Zinit配置
date: '2021-04-21 10:03:14'
updated: '2026-06-15 19:47:53'
tags: [Zinit, zsh]
permalink: /articles/2021/10/02/1618970594540.html
---
# 安装

1. 首先执行官方安装脚本

```zsh
sh -c "$(curl -fsSL https://raw.githubusercontent.com/zdharma-continuum/zinit/master/doc/install.sh)"
```

# 添加相关插件

2. 在 ``~/.zshrc``中添加配置并source安装插件

```zsh
# z.lua
zinit ice lucid wait='1'
zinit light skywind3000/z.lua
# p10k界面
zinit ice depth=1
zinit light romkatv/powerlevel10k
# 高亮
zinit ice lucid wait='0' atinit='zpcompinit'
zinit light zdharma-continuum/fast-syntax-highlighting
# 提示
zinit ice lucid wait='0' atload='_zsh_autosuggest_start'
zinit light zsh-users/zsh-autosuggestions
# 自动补全
zinit ice lucid wait='0'
zinit light zsh-users/zsh-completions
```

* 需要注意p10k可能需要安装相关字体才能使用除了pure以外的主题配置

# ZSH启动慢

如果觉得ZSH启动过慢，可以使用ZSH提供的工具检查

在.zshrc最前面添加:

```zsh
zmodload zsh/zprof
```

在.zshrc最后面添加:

```zsh
zprof
```

然后打开一个新的窗口会打印所有脚本的加载时间等信息

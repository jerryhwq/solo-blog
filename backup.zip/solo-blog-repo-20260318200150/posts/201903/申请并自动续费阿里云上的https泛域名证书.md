title: 申请并自动续费阿里云上的https泛域名证书
date: '2019-03-24 14:38:18'
updated: '2023-08-10 12:37:25'
tags: [letsencrypt, certbot, acme.sh]
permalink: /articles/2019/03/24/1553409497931.html
---
目前有很多种方式使用Let's Encrypt证书，主流的方式有acme.sh和certbot等

## acme.sh

使用脚本安装acme.sh:

```shell
curl https://get.acme.sh | sh -s email=邮箱地址
```

现在默认acme.sh使用zerossl, 如果出现失败可以改用Let's Encrypt:

```shell
acme.sh --set-default-ca --server letsencrypt
```

这个脚本会自动向crontab中添加定时任务，可以向后面追加nginx重启命令:

```
44 0 * * * "/home/ecs-user/.acme.sh"/acme.sh --cron --home "/home/ecs-user/.acme.sh" > /dev/null && sudo nginx -s reload
```

设置阿里云的access key信息:

```shell
export Ali_Key=access_key_id
export Ali_Secret=access_key_secret
```

申请证书:

```shell
acme.sh --issue --dns dns_ali -d huwenqiang.cn -d *.huwenqiang.cn
```

证书会生成到类似下面的位置:

```
/home/ecs-user/.acme.sh/huwenqiang.cn_ecc
```

## Certbot

首先下载 certbot-auto 脚本：

```shell
wget https://dl.eff.org/certbot-auto
chmod a+x certbot-auto
```

然后使用 pip 安装 aliyun-python-sdk-alidns，同时新建如下脚本，并将 access_key_id 和 access_key_secret 换掉：

```python3
import os
from aliyunsdkcore.client import AcsClient
from aliyunsdkalidns.request.v20150109 import AddDomainRecordRequest

access_key_id =  'access_key_id'
access_key_secret =  'access_key_secret'

domain = os.environ["CERTBOT_DOMAIN"]
value = os.environ["CERTBOT_VALIDATION"]

print("--------------->domain="  + domain)
print("--------------->value="  + value)

client = AcsClient(access_key_id, access_key_secret)
request = AddDomainRecordRequest.AddDomainRecordRequest()
request.set_DomainName(domain)
request.set_RR('_acme-challenge')
request.set_Type('TXT')
request.set_Value(value)
response = client.do_action_with_exception(request)

print(response)
```

执行下面的脚本创建证书：

```shell
./certbot-auto certonly -d huwenqiang.cn -d *.huwenqiang.cn --manual --preferred-challenges dns --server https://acme-v02.api.letsencrypt.org/directory --manual-auth-hook ./dns.py
```

执行下面的命令就可以自动续期：

```shell
./certbot-auto renew --manual --preferred-challenges dns  --manual-auth-hook ./dns.py
```

可以使用 crontab 新建定时任务实现自动刷新并重启 nginx 服务器：

```
0 0 15 */3 * /certbot/certbot-auto renew && /usr/sbin/nginx -s reload
```

* 附：nginx 配置文件

```nginx
map $http_upgrade $connection_upgrade {
    default upgrade;
    '' close;
}

server {
    listen       443 ssl http2;
    server_name  www.huwenqiang.cn;
    ssl_certificate /etc/letsencrypt/live/huwenqiang.cn/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/huwenqiang.cn/privkey.pem;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384:DHE-RSA-CHACHA20-POLY1305;
    ssl_prefer_server_ciphers off;

    gzip on;
    gzip_min_length 1k;
    gzip_buffers 4 16k;
    gzip_comp_level 2;
    gzip_types text/plain application/javascript application/x-javascript text/css application/xml text/javascript application/x-httpd-php image/jpeg image/gif image/png;
    gzip_vary off;
    gzip_disable "MSIE [1-6]\.";

    location / {
        proxy_pass http://solo:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;
    }

    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
        root   /usr/share/nginx/html;
    }
}

server {
    listen 80;
    server_name www.huwenqiang.cn;
    return 301 https://www.huwenqiang.cn$request_uri;
}
```
